import boto3
import os
from datetime import date, timedelta, datetime
import boto3
import yfinance as yf
import pandas as pd
import io

ssm_client = boto3.client('ssm')
s3 = boto3.client('s3')

def get_variable(variable_name):
    return ssm_client.get_parameter(
        Name=variable_name, 
        WithDecryption=False
    )['Parameter']['Value']

s3_root = get_variable("s3_root")
ticker = get_variable("ticker")
ticker_start_date = datetime.strptime(get_variable("ticker_start_date"), '%Y-%m-%d').date()
ticker_last_update = datetime.strptime(get_variable("ticker_last_update"), '%Y-%m-%d').date()

def lambda_handler(event, context):

    today = date.today()

    # print all variables
    print(f"s3_root: {s3_root}")
    print(f"ticker: {ticker}")
    print(f"ticker_start_date: {ticker_start_date}")
    print(f"ticker_last_update: {ticker_last_update}")

    return {
        'statusCode': 200,
        'body': f"S3 root: {s3_root}"
    }


if os.getenv("LOCAL_ENV"):
    lambda_handler(None, None)